$(document).ready(function(){
	$(".owl-carousel").owlCarousel({
		items: 3
	
	});

})